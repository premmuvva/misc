from django.apps import AppConfig


class MagzappConfig(AppConfig):
    name = 'magzapp'
